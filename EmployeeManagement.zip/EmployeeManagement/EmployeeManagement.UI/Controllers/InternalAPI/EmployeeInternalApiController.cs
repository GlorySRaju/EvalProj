﻿using EmployeeManagement.DataAccess.Models;
using EmployeeManagement.UI.Models;
using EmployeeManagement.UI.Providers.Contracts;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagement.UI.Controllers.InternalAPI
{
    [Route("GetEmployees")]
    [ApiController]
    public class EmployeeInternalApiController : ControllerBase
    {
        private readonly IEmployeeApiClient _employeeApiClient;

        public EmployeeInternalApiController(IEmployeeApiClient employeeApiClient)
        {
            _employeeApiClient = employeeApiClient;
        }

        [HttpGet]
        [Route("{employeeId}")]
        public IActionResult GetEmployeeById([FromRoute] int employeeId)
        {
            try
            {
                var employee = _employeeApiClient.GetEmployeeById(employeeId);

                return Ok(employee);
            }
            catch (Exception ex)
            {

                throw;
            }

        }
        [HttpPost]
        public IActionResult InsertEmployee([FromBody] EmployeeDetailedViewModel employee)
        {
            try
            {
                var employees = _employeeApiClient.InsertEmployee(employee);

                return Ok(employees);
            }
            catch (Exception ex)
            {

                throw;
            }

        }

        [HttpPut]

        [Route("{id}")]
        public IActionResult UpdateEmployee([FromBody] EmployeeDetailedViewModel employee,[FromRoute] int id)
        {
            try
            {
                employee.Id = id;

                var employees = _employeeApiClient.UpdateEmployee(employee);

                return Ok(employees);
            }
            catch (Exception ex)
            {

                throw;
            }

        }

        [HttpDelete]

        [Route("{id}")]
        public IActionResult DeleteEmployee([FromRoute] int id)
        {
            try
            {
                var employees = _employeeApiClient.DeleteEmployee(id);

                return Ok(employees);
            }
            catch (Exception ex)
            {

                throw;
            }

        }
    }
}
