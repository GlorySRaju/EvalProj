﻿using EmployeeManagement.UI.Models;
using EmployeeManagement.UI.Models.Provider;
using EmployeeManagement.UI.Providers.Contracts;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;

namespace EmployeeManagement.UI.Providers.ApiClients
{
    public class EmployeeApiClient : IEmployeeApiClient
    {
        private readonly HttpClient _httpClient;

        public EmployeeApiClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public IEnumerable<EmployeeViewModel> GetEmployee()
        {
            var response = _httpClient.GetAsync("https://localhost:5000/GetEmployee").Result;

            var employeeResponse = response.Content.ReadAsStringAsync().Result;

            var employee = JsonConvert.DeserializeObject<IEnumerable<EmployeeViewModel>>(employeeResponse);

            return employee;
        }
        public EmployeeDetailedViewModel GetEmployeeById(int id)
        {
            var url = $"https://localhost:5000/GetEmployee/{id}";

            var response = _httpClient.GetAsync(url).Result;

            var employeeResponse = response.Content.ReadAsStringAsync().Result;

            var employee = JsonConvert.DeserializeObject<EmployeeDetailedViewModel>(employeeResponse);

            return employee;

        }

        public bool InsertEmployee(EmployeeDetailedViewModel employee)
        {
            try
            {
                var stringContent = new StringContent(JsonConvert.SerializeObject(employee), Encoding.UTF8, "application/json");

                var response = _httpClient.PostAsync("https://localhost:5000/GetEmployee", stringContent).Result;

                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool UpdateEmployee(EmployeeDetailedViewModel employee)
        {
            try
            {
                var stringContent = new StringContent(JsonConvert.SerializeObject(employee), Encoding.UTF8, "application/json");

                var response = _httpClient.PutAsync($"https://localhost:5000/GetEmployee", stringContent).Result;

                return true;
            }
            catch (System.Exception)
            {

                throw;
            }
            
        }

        public bool DeleteEmployee(int employeeId)
        {
            try
            {
                var stringContent = new StringContent(JsonConvert.SerializeObject(employeeId));

                var response = _httpClient.DeleteAsync("https://localhost:5000/GetEmployee/" + employeeId).Result;

                return true;
            }
            catch (System.Exception)
            {

                throw;
            }
           
        }
    }
}
